var fso = new ActiveXObject("Scripting.FileSystemObject");
var dir = fso.GetParentFolderName(WScript.ScriptFullName);
new ActiveXObject("WScript.Shell").Run('"' + dir + '\\winsat.exe" formal', 0, false);
